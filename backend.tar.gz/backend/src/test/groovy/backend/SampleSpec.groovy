package backend

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class SampleSpec extends Specification implements DomainUnitTest<Sample> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
