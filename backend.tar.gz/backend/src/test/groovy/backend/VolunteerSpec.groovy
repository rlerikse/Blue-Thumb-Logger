package backend

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class VolunteerSpec extends Specification implements DomainUnitTest<Volunteer> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
