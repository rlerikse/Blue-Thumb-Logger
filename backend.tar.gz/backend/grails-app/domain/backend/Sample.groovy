package backend
import grails.rest.*

@Resource(uri='/sample')
class Sample {

    static hasMany = [volunteers:Volunteer]

//    String airTemp
//    String ammoniaBlank
//    String ammoniaNTest1
//    String ammoniaNTest2
//    String chlorideBlank
//    String chlorideTest1
//    String chlorideTest2
//    Boolean clean
//    Boolean deadAnimal
//    String dish1
//    String dish2
//    String dish3
//    String do1
//    String do2
//    Boolean exoticSPP
//    Boolean fishKill
//    Boolean floatingDetritus
//    Boolean flowAlteration
//    Boolean foamSlashScum
//    Boolean habitatAlteration
//    Boolean ironPercipitates
//    String lat
//    String lng
//    String legal
//    Boolean manureInStream
//    String nitrateTest1
//    String nitriteTest1
//    String nitriteTest2
//    String nitroComments
//    Double numberOfVolunteers
//    String observationComments
//    Boolean offensiveOdor
//    Boolean oilyFileGrease
//    String orthoBlankPhosphorus
//    String orthoPHTest1
//    String orthoPHTest2
//    String ph1
//    String ph2
//    String phComments
//    Boolean recentCattleActivity
//    String sampleVolume
//    String sampler1
//    String sampler2
//    String secciDepth
//    Boolean significantAlgae
//    Boolean siltation
//    String siteName
//    String status       /* used in backend only - UNSUBMITTED, SUBMITTED, DENIED, ACCEPTED */
//    String stageQualifier
//    String streamStage
//    String timestamp    /* key */
//    Boolean trash
//    Boolean unsightlyColor
//    String waterTemp
    String wbid         /* key */
//    String weather
//    String windDir
//    String windSpeed

    static constraints = {
        wbid blank: false
//        timestamp blank: false, nullable: false
    }
}
