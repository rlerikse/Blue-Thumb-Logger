package backend
import grails.rest.*

@Resource(uri='/volunteer')
class Volunteer {

    static belongsTo = [sample:Sample]
    String name
    String hours
    String activity

    static constraints = {
        name blank: false
    }
}
