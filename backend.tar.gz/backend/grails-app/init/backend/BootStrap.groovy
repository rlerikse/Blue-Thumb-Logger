package backend

import grails.converters.JSON

class BootStrap {

    def init = { servletContext ->
        def sample = new Sample(wbid:"1234",waterTemp:"a", timestamp:"a")
                .addToVolunteers(new Volunteer(name:"Logan",hours:"1",activity:"asdf"))
                .save(flush:true)
        volunteerMarshaler()
    }
    def destroy = {
    }
    private void volunteerMarshaler() {
        JSON.registerObjectMarshaller(Sample) { sample ->
            [
                    id: sample.id,
                    wbid: sample.wbid,
                    volunteer: sample.volunteers.collect { v ->
                        [
                                id: v.id,
                                name: v.name,
                                hours: v.hours,
                                activity: v.activity
                        ]
                    }
            ]
        }
    }
}
